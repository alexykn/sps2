#include <stdio.h>

int main(int argc, char *argv[]) {
    printf("Hello from spsv2!\n");
    return 0;
}